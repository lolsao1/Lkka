# Theme Fixes
This will be where themes submitted to the BetterDiscord serve and the develeoper has decided to discontinue updates.  
  
At some point they will become auto-updating.  
  
  I will not help you if you copy the code and put it in customCSS. Right-click the raw button on the theme page and save to your theme folder. DO NOT CHANGE THE NAME.
